# Tavern Fighter

Picchiaduro arcade originale in 2.5D sviluppato con Godot 4.7.2. La nuova copertina e l'icona sono ispirate a una taverna fantasy; personaggi e arena sono ancora prototipi stilizzati.

## Avvio

Avvia `Tavern-Fighter.exe` nella cartella `outputs`. Per modificare il progetto, importa `project.godot` in Godot 4.7 o successivo.

## Aggiornamenti dal gioco

Dal menu apri **Aggiornamenti**, inserisci l'indirizzo HTTPS del file `latest.json` e scegli **Salva e controlla**. Il gioco ricorda il link e controlla gli aggiornamenti ai successivi avvii. Quando trova una versione più recente, puoi scaricarla e installarla direttamente dal menu.

Per pubblicare una versione, ospita su un sito HTTPS l'eseguibile Windows e un manifest JSON con questa forma:

```json
{
  "version": "1.0.1",
  "download_url": "https://tuo-sito.example/Tavern-Fighter.exe",
  "sha256": "INSERISCI_QUI_L_HASH_SHA256_DI_64_CARATTERI",
  "release_notes": "Descrizione delle novità"
}
```

Pubblica prima l'eseguibile e poi il manifest, mantenendo il link del manifest invariato. L'installatore verifica l'hash prima di sostituire il gioco e riavvia Tavern Fighter. Il file eseguibile deve trovarsi in una cartella in cui l'utente può scrivere. Per distribuire aggiornamenti reali manca ancora scegliere e configurare un hosting pubblico.

## Multiplayer online

Dal menu scegli **Multiplayer online**. Chi ospita crea la partita e comunica il proprio IP; l'altro giocatore inserisce quell'IP e si unisce. Per giocare da reti diverse, chi ospita deve inoltrare la porta UDP 24568 sul router e consentire il gioco nel firewall. Non c'è ancora un servizio di ricerca partite o relay.

## Comandi

| Azione | Giocatore 1 | Giocatore 2 |
| --- | --- | --- |
| Movimento sul piano | A / D | Frecce sinistra / destra |
| Profondità arena | W / S | Frecce su / giù |
| Salto | Spazio | Maiusc destro |
| Attacco leggero | J | 1 |
| Attacco pesante | K | 2 |
| Attacco speciale | L | 3 |
| Parata | C | Ctrl destro |
| Pausa | Esc | Esc |

La cartella `assets` contiene la copertina e l'icona dell'app; `audio` contiene gli effetti sonori originali.
