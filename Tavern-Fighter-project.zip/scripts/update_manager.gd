extends Node
class_name TavernUpdater

signal status_changed(message: String)
signal update_available(version: String, notes: String)
signal update_failed(message: String)
signal update_staged(version: String)

const GAME_VERSION := "1.0.0"
const MAX_DOWNLOAD_BYTES := 500 * 1024 * 1024

var manifest_request: HTTPRequest
var download_request: HTTPRequest
var manifest_url := ""
var release_url := ""
var release_sha256 := ""
var release_version := ""

func _ready() -> void:
	manifest_request = HTTPRequest.new()
	manifest_request.timeout = 30.0
	manifest_request.max_redirects = 8
	manifest_request.request_completed.connect(_on_manifest_received)
	add_child(manifest_request)
	download_request = HTTPRequest.new()
	download_request.timeout = 180.0
	download_request.max_redirects = 8
	download_request.body_size_limit = MAX_DOWNLOAD_BYTES
	download_request.request_completed.connect(_on_release_received)
	add_child(download_request)

func check_for_updates(url: String) -> void:
	manifest_url = url.strip_edges()
	if not manifest_url.begins_with("https://"):
		update_failed.emit("Il link degli aggiornamenti deve iniziare con https://")
		return
	status_changed.emit("Controllo la versione più recente…")
	var result := manifest_request.request(manifest_url, ["Accept: application/json"])
	if result != OK:
		update_failed.emit("Non riesco ad avviare la richiesta. Controlla il link e la connessione.")

func download_update() -> void:
	if release_url.is_empty() or release_sha256.length() != 64:
		update_failed.emit("Prima controlla gli aggiornamenti.")
		return
	if not release_url.begins_with("https://"):
		update_failed.emit("Il file di aggiornamento deve essere ospitato su HTTPS.")
		return
	status_changed.emit("Scarico Tavern Fighter %s…" % release_version)
	var result := download_request.request(release_url)
	if result != OK:
		update_failed.emit("Non riesco ad avviare il download.")

func _on_manifest_received(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		update_failed.emit("Non riesco a leggere il manifest degli aggiornamenti (HTTP %d)." % response_code)
		return
	var data: Variant = JSON.parse_string(body.get_string_from_utf8())
	if not data is Dictionary:
		update_failed.emit("Il manifest non è un JSON valido.")
		return
	var remote_version := str(data.get("version", "")).trim_prefix("v")
	var remote_url := str(data.get("download_url", ""))
	var remote_sha := str(data.get("sha256", "")).to_lower()
	if remote_version.is_empty() or remote_url.is_empty() or remote_sha.length() != 64:
		update_failed.emit("Il manifest deve contenere version, download_url e sha256.")
		return
	if not _is_newer_version(remote_version, GAME_VERSION):
		status_changed.emit("Tavern Fighter è aggiornato · versione %s." % GAME_VERSION)
		return
	release_version = remote_version
	release_url = remote_url
	release_sha256 = remote_sha
	update_available.emit(release_version, str(data.get("release_notes", "Nuova versione disponibile.")))

func _on_release_received(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code < 200 or response_code >= 300:
		update_failed.emit("Download non riuscito (HTTP %d)." % response_code)
		return
	if body.size() < 1024 * 1024 or body.size() > MAX_DOWNLOAD_BYTES or body[0] != 0x4d or body[1] != 0x5a:
		update_failed.emit("Il file scaricato non sembra un eseguibile Windows valido.")
		return
	var hasher := HashingContext.new()
	if hasher.start(HashingContext.HASH_SHA256) != OK or hasher.update(body) != OK:
		update_failed.emit("Non riesco a verificare il file scaricato.")
		return
	if hasher.finish().hex_encode().to_lower() != release_sha256:
		update_failed.emit("Verifica SHA-256 non riuscita. Il gioco non verrà sostituito.")
		return
	if OS.get_name() != "Windows":
		update_failed.emit("L'aggiornamento automatico è configurato per Windows.")
		return
	var executable := OS.get_executable_path()
	var folder := executable.get_base_dir()
	var staged_path := folder.path_join("TavernFighter.update.exe")
	var staged_file := FileAccess.open(staged_path, FileAccess.WRITE)
	if staged_file == null:
		update_failed.emit("Non posso scrivere nella cartella del gioco. Spostalo in una cartella modificabile e riprova.")
		return
	staged_file.store_buffer(body)
	staged_file.close()
	var updater_path := folder.path_join("TavernFighter.update.bat")
	var process_id := OS.get_process_id()
	var batch := "@echo off\r\n:wait_for_game\r\ntasklist /FI \"PID eq %d\" /NH | find \"%d\" >nul\r\nif not errorlevel 1 (timeout /t 1 /nobreak >nul & goto wait_for_game)\r\ncopy /Y \"%s\" \"%s\" >nul\r\nif errorlevel 1 goto update_failed\r\nstart \"\" \"%s\"\r\ndel \"%s\"\r\nexit /b 0\r\n:update_failed\r\necho Impossibile installare l'aggiornamento.\r\ntimeout /t 5 >nul\r\n" % [process_id, process_id, staged_path, executable, executable, staged_path]
	var batch_file := FileAccess.open(updater_path, FileAccess.WRITE)
	if batch_file == null:
		DirAccess.remove_absolute(staged_path)
		update_failed.emit("Non posso preparare l'installazione dell'aggiornamento.")
		return
	batch_file.store_string(batch)
	batch_file.close()
	var command := OS.get_environment("COMSPEC")
	if command.is_empty():
		command = "cmd.exe"
	if OS.create_process(command, ["/C", updater_path], false) < 0:
		DirAccess.remove_absolute(staged_path)
		DirAccess.remove_absolute(updater_path)
		update_failed.emit("Windows non ha avviato il programma di aggiornamento.")
		return
	update_staged.emit(release_version)
	get_tree().create_timer(1.0).timeout.connect(func() -> void: get_tree().quit())

func _is_newer_version(remote: String, local: String) -> bool:
	var remote_parts := remote.split(".")
	var local_parts := local.split(".")
	for index in range(3):
		var remote_number := int(remote_parts[index]) if index < remote_parts.size() else 0
		var local_number := int(local_parts[index]) if index < local_parts.size() else 0
		if remote_number != local_number:
			return remote_number > local_number
	return false
