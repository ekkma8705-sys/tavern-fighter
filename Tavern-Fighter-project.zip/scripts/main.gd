extends Node3D

const FIGHTER_SCENE := preload("res://scenes/fighter.tscn")
const SFX_ROUND := preload("res://audio/round.wav")
const SFX_FIGHT := preload("res://audio/fight.wav")
const TAVERN_COVER := preload("res://assets/tavern_cover.svg")
const UPDATE_MANIFEST_URL := "https://raw.githubusercontent.com/ekkma8705-sys/tavern-fighter/main/updates/latest.json"
const ARENA_WIDTH := 1600.0
const ARENA_HEIGHT := 900.0

var fighters: Array[StormFighter] = []
var round_number := 1
var wins := [0, 0]
var round_time := 99.0
var fight_state := "menu"
var state_timer := 0.0
var versus_mode := false
var hud_layer: CanvasLayer
var menu_layer: Control
var announcement: Label
var announcement_subtitle: Label
var timer_label: Label
var controls_label: Label
var ui_sound_player: AudioStreamPlayer
var health_bars: Array[ProgressBar] = []
var round_pips: Array[Array] = [[], []]
var versus_button: Button
var menu_column: VBoxContainer
var online_panel: PanelContainer
var address_field: LineEdit
var network_status: Label
var online_mode := false
var latest_remote_input: Dictionary = {}
var sync_timer := 0.0
var previous_network_state := "menu"
var previous_network_round := 1
var previous_network_wins := [0, 0]
var previous_winner := 0
var network_client_id := 0
var updater: TavernUpdater
var update_panel: PanelContainer
var update_manifest_field: LineEdit
var update_status_label: Label
var update_download_button: Button

const NETWORK_PORT := 24568

func _ready() -> void:
	randomize()
	ui_sound_player = AudioStreamPlayer.new()
	ui_sound_player.name = "InterfaceAudio"
	add_child(ui_sound_player)
	_build_stage_details()
	_build_hud()
	_build_menu()
	updater = TavernUpdater.new()
	updater.name = "TavernUpdater"
	add_child(updater)
	updater.status_changed.connect(_on_update_status)
	updater.update_available.connect(_on_update_available)
	updater.update_failed.connect(_on_update_failed)
	updater.update_staged.connect(_on_update_staged)
	var saved_manifest := ConfigFile.new()
	var update_url := UPDATE_MANIFEST_URL
	if saved_manifest.load("user://update.cfg") == OK:
		update_url = str(saved_manifest.get_value("updates", "manifest_url", update_url))
	updater.check_for_updates.call_deferred(update_url)
	_spawn_fighters()

func _process(delta: float) -> void:
	if online_mode:
		if multiplayer.is_server():
			_process_online_host(delta)
		else:
			_send_online_input()
		return
	if fight_state == "fight":
		round_time = maxf(0.0, round_time - delta)
		for fighter in fighters:
			fighter.tick_fight(delta)
		timer_label.text = str(ceili(round_time)).pad_zeros(2)
		if round_time <= 0.0:
			_finish_round(0 if fighters[0].health >= fighters[1].health else 1)
	elif fight_state == "intro" or fight_state == "roundover":
		state_timer -= delta
		if state_timer <= 0.0:
			if fight_state == "intro":
				fight_state = "fight"
				_play_ui_sound(SFX_FIGHT, -3.0)
				_show_announcement("FIGHT!", "", 0.65)
			else:
				if wins[0] >= 2 or wins[1] >= 2:
					fight_state = "over"
					_show_announcement("RAIJIN VINCE" if wins[0] > wins[1] else "VEX VINCE", "PREMI R PER RICOMINCIARE", 999.0)
				else:
					round_number += 1
					_start_round()
	elif fight_state == "over" and Input.is_action_just_pressed("ui_accept"):
		_start_game()
	if Input.is_action_just_pressed("pause"):
		_toggle_pause()

func _process_online_host(delta: float) -> void:
	if fight_state == "fight":
		round_time = maxf(0.0, round_time - delta)
		if fighters.size() == 2:
			fighters[0].tick_fight(delta)
			fighters[1].tick_fight(delta, latest_remote_input)
		timer_label.text = str(ceili(round_time)).pad_zeros(2)
		if round_time <= 0.0 and fighters.size() == 2:
			_finish_round(0 if fighters[0].health >= fighters[1].health else 1)
	elif fight_state == "intro" or fight_state == "roundover":
		state_timer -= delta
		if state_timer <= 0.0:
			if fight_state == "intro":
				fight_state = "fight"
				_play_ui_sound(SFX_FIGHT, -3.0)
				_show_announcement("FIGHT!", "", 0.65)
			else:
				if wins[0] >= 2 or wins[1] >= 2:
					fight_state = "over"
					_show_announcement("RAIJIN VINCE" if wins[0] > wins[1] else "VEX VINCE", "PREMI INVIO PER RICOMINCIARE", 999.0)
				else:
					round_number += 1
					_start_round()
	elif fight_state == "over" and Input.is_action_just_pressed("ui_accept"):
		_begin_online_match()
	if Input.is_action_just_pressed("pause"):
		_toggle_pause()
	sync_timer += delta
	if sync_timer >= 0.05:
		sync_timer = 0.0
		_broadcast_online_state()

func _build_stage_details() -> void:
	var stage := $Arena
	var skybox := MeshInstance3D.new()
	skybox.name = "Moon"
	var moon := SphereMesh.new()
	moon.radius = 1.2
	moon.height = 2.4
	skybox.mesh = moon
	skybox.position = Vector3(3.5, 5.0, -10.0)
	var moon_mat := StandardMaterial3D.new()
	moon_mat.albedo_color = Color("d9d4ff")
	moon_mat.emission_enabled = true
	moon_mat.emission = Color("9f99ff")
	moon_mat.emission_energy_multiplier = 1.3
	skybox.material_override = moon_mat
	stage.add_child(skybox)
	for index in range(11):
		var width := randf_range(0.8, 1.5)
		var height := randf_range(2.4, 5.7)
		var building := MeshInstance3D.new()
		building.name = "SkylineTower%02d" % index
		var box := BoxMesh.new()
		box.size = Vector3(width, height, 0.55)
		building.mesh = box
		building.position = Vector3(-9.3 + index * 1.83, height * 0.5 - 0.5, -7.0)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color("19182e") if index % 2 == 0 else Color("22203a")
		mat.emission_enabled = true
		mat.emission = Color("282648")
		mat.emission_energy_multiplier = 0.3
		building.material_override = mat
		stage.add_child(building)
		for row in range(3):
			var window := MeshInstance3D.new()
			var pane := BoxMesh.new()
			pane.size = Vector3(0.08, 0.16, 0.025)
			window.mesh = pane
			window.position = building.position + Vector3(randf_range(-width * 0.32, width * 0.32), randf_range(-height * 0.3, height * 0.3), -0.3)
			var glass := StandardMaterial3D.new()
			glass.albedo_color = Color("65dce1") if randf() < 0.62 else Color("d779a1")
			glass.emission_enabled = true
			glass.emission = glass.albedo_color
			glass.emission_energy_multiplier = 0.9
			window.material_override = glass
			stage.add_child(window)
	for index in range(13):
		var line := MeshInstance3D.new()
		var bar := BoxMesh.new()
		bar.size = Vector3(0.025, 0.012, 6.0)
		line.mesh = bar
		var position_z := -3.0 + float(index) * 0.5
		line.position = Vector3(0, 0.115, position_z)
		var line_mat := StandardMaterial3D.new()
		line_mat.albedo_color = Color("56dce7")
		line_mat.emission_enabled = true
		line_mat.emission = Color("287d92")
		line_mat.emission_energy_multiplier = 0.6
		line.material_override = line_mat
		stage.add_child(line)
	for index in range(9):
		var seam := MeshInstance3D.new()
		var mark := BoxMesh.new()
		mark.size = Vector3(0.025, 0.014, 7.0)
		seam.mesh = mark
		seam.position = Vector3(-6.0 + index * 1.5, 0.12, 0)
		seam.rotation.y = PI / 2.0
		var seam_mat := StandardMaterial3D.new()
		seam_mat.albedo_color = Color("51537b")
		seam_mat.emission_enabled = true
		seam_mat.emission = Color("33375b")
		seam.material_override = seam_mat
		stage.add_child(seam)

func _build_hud() -> void:
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 5
	add_child(hud_layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_layer.add_child(root)
	for index in range(2):
		var right_side := index == 1
		var panel := VBoxContainer.new()
		panel.anchor_left = 0.055 if not right_side else 0.555
		panel.anchor_right = 0.445 if not right_side else 0.945
		panel.offset_top = 38
		panel.offset_bottom = 130
		panel.add_theme_constant_override("separation", 8)
		root.add_child(panel)
		var row := HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_END if right_side else BoxContainer.ALIGNMENT_BEGIN
		panel.add_child(row)
		var name_label := Label.new()
		name_label.text = "VEX   ·   LAMA D'OMBRA" if right_side else "RAIJIN   ·   IL FULMINE"
		name_label.add_theme_font_size_override("font_size", 23)
		name_label.add_theme_color_override("font_color", Color("fff0f5") if right_side else Color("d6ffff"))
		name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if right_side:
			name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(name_label)
		var bar := ProgressBar.new()
		bar.min_value = 0
		bar.max_value = 100
		bar.value = 100
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(0, 27)
		bar.add_theme_stylebox_override("background", _flat_style(Color("19192a")))
		bar.add_theme_stylebox_override("fill", _flat_style(Color("ff668f") if right_side else Color("60eee1")))
		panel.add_child(bar)
		health_bars.append(bar)
	var center := VBoxContainer.new()
	center.anchor_left = 0.42
	center.anchor_right = 0.58
	center.offset_top = 20
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	root.add_child(center)
	var round_label := Label.new()
	round_label.name = "RoundLabel"
	round_label.text = "ROUND 01"
	round_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	round_label.add_theme_font_size_override("font_size", 15)
	round_label.add_theme_color_override("font_color", Color("ceceef"))
	center.add_child(round_label)
	var pips := HBoxContainer.new()
	pips.name = "Pips"
	pips.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(pips)
	for index in range(4):
		var pip := ColorRect.new()
		pip.custom_minimum_size = Vector2(9, 9)
		pip.color = Color("60617c")
		pip.rotation = PI / 4.0
		pips.add_child(pip)
		round_pips[0 if index < 2 else 1].append(pip)
	timer_label = Label.new()
	timer_label.text = "99"
	timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	timer_label.add_theme_font_size_override("font_size", 35)
	timer_label.add_theme_color_override("font_color", Color.WHITE)
	center.add_child(timer_label)
	announcement = Label.new()
	announcement.anchor_left = 0.1
	announcement.anchor_right = 0.9
	announcement.anchor_top = 0.31
	announcement.anchor_bottom = 0.46
	announcement.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	announcement.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	announcement.add_theme_font_size_override("font_size", 68)
	announcement.add_theme_color_override("font_color", Color.WHITE)
	announcement.add_theme_color_override("font_shadow_color", Color("8d89ff"))
	announcement.add_theme_constant_override("shadow_offset_x", 1)
	announcement.add_theme_constant_override("shadow_offset_y", 5)
	root.add_child(announcement)
	announcement_subtitle = Label.new()
	announcement_subtitle.anchor_left = 0.1
	announcement_subtitle.anchor_right = 0.9
	announcement_subtitle.anchor_top = 0.45
	announcement_subtitle.anchor_bottom = 0.53
	announcement_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	announcement_subtitle.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	announcement_subtitle.add_theme_font_size_override("font_size", 19)
	announcement_subtitle.add_theme_color_override("font_color", Color("d0d8ff"))
	root.add_child(announcement_subtitle)
	controls_label = Label.new()
	controls_label.anchor_left = 0.03
	controls_label.anchor_right = 0.97
	controls_label.anchor_top = 0.94
	controls_label.anchor_bottom = 1.0
	controls_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_label.add_theme_font_size_override("font_size", 16)
	controls_label.add_theme_color_override("font_color", Color("c2c5e0"))
	root.add_child(controls_label)
	announcement.visible = false
	announcement_subtitle.visible = false

func _build_menu() -> void:
	menu_layer = ColorRect.new()
	menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.color = Color(0.025, 0.028, 0.07, 0.84)
	menu_layer.z_index = 10
	hud_layer.add_child(menu_layer)
	var cover := TextureRect.new()
	cover.texture = TAVERN_COVER
	cover.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	cover.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	cover.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cover.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(cover)
	var shade := ColorRect.new()
	shade.color = Color(0.035, 0.018, 0.008, 0.62)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(shade)
	menu_column = VBoxContainer.new()
	menu_column.anchor_left = 0.22
	menu_column.anchor_right = 0.78
	menu_column.anchor_top = 0.16
	menu_column.anchor_bottom = 0.87
	menu_column.alignment = BoxContainer.ALIGNMENT_CENTER
	menu_column.add_theme_constant_override("separation", 10)
	menu_layer.add_child(menu_column)
	var eyebrow := Label.new()
	eyebrow.text = "L A   T A V E R N A   D E I   C A M P I O N I"
	eyebrow.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	eyebrow.add_theme_font_size_override("font_size", 18)
	eyebrow.add_theme_color_override("font_color", Color("7feaff"))
	menu_column.add_child(eyebrow)
	var title := Label.new()
	title.text = "TAVERN\nFIGHTER"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 80)
	title.add_theme_color_override("font_color", Color("e7e6ff"))
	menu_column.add_child(title)
	var tagline := Label.new()
	tagline.text = "UNA TAVERNA. DUE CAMPIONI. UN SOLO VINCITORE."
	tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tagline.add_theme_font_size_override("font_size", 20)
	tagline.add_theme_color_override("font_color", Color("bdc2dd"))
	menu_column.add_child(tagline)
	var start := Button.new()
	start.text = "INIZIA IL COMBATTIMENTO"
	start.custom_minimum_size = Vector2(310, 56)
	start.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	start.add_theme_font_size_override("font_size", 18)
	start.pressed.connect(_start_game)
	menu_column.add_child(start)
	versus_button = Button.new()
	versus_button.text = "MODALITÀ: 1 GIOCATORE  ·  PREMI PER CAMBIARE"
	versus_button.custom_minimum_size = Vector2(370, 42)
	versus_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	versus_button.pressed.connect(_toggle_mode)
	menu_column.add_child(versus_button)
	var online_button := Button.new()
	online_button.text = "MULTIPLAYER ONLINE"
	online_button.custom_minimum_size = Vector2(310, 46)
	online_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	online_button.add_theme_font_size_override("font_size", 17)
	online_button.pressed.connect(_show_online_panel)
	menu_column.add_child(online_button)
	var updates_button := Button.new()
	updates_button.text = "AGGIORNAMENTI"
	updates_button.custom_minimum_size = Vector2(310, 44)
	updates_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	updates_button.pressed.connect(_show_update_panel)
	menu_column.add_child(updates_button)
	var note := Label.new()
	note.text = "PICCHIADURO ARCADE 2.5D  ·  VERSIONE 1.0.0"
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.add_theme_font_size_override("font_size", 14)
	note.add_theme_color_override("font_color", Color("858aaa"))
	menu_column.add_child(note)
	online_panel = PanelContainer.new()
	online_panel.anchor_left = 0.28
	online_panel.anchor_right = 0.72
	online_panel.anchor_top = 0.21
	online_panel.anchor_bottom = 0.81
	online_panel.z_index = 2
	menu_layer.add_child(online_panel)
	var online_content := VBoxContainer.new()
	online_content.alignment = BoxContainer.ALIGNMENT_CENTER
	online_content.add_theme_constant_override("separation", 12)
	online_panel.add_child(online_content)
	var online_title := Label.new()
	online_title.text = "SFIDA ONLINE"
	online_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	online_title.add_theme_font_size_override("font_size", 30)
	online_title.add_theme_color_override("font_color", Color("7feaff"))
	online_content.add_child(online_title)
	var address_label := Label.new()
	address_label.text = "INDIRIZZO IP DELL'HOST"
	address_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	address_label.add_theme_font_size_override("font_size", 15)
	online_content.add_child(address_label)
	address_field = LineEdit.new()
	address_field.placeholder_text = "es. 192.168.1.25"
	address_field.text = "127.0.0.1"
	address_field.custom_minimum_size = Vector2(350, 42)
	address_field.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	address_field.alignment = HORIZONTAL_ALIGNMENT_CENTER
	online_content.add_child(address_field)
	var host_button := Button.new()
	host_button.text = "CREA PARTITA · OSPITA"
	host_button.custom_minimum_size = Vector2(350, 46)
	host_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	host_button.pressed.connect(_host_online_game)
	online_content.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "UNISCITI ALLA PARTITA"
	join_button.custom_minimum_size = Vector2(350, 46)
	join_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	join_button.pressed.connect(_join_online_game)
	online_content.add_child(join_button)
	network_status = Label.new()
	network_status.text = "Stessa rete oppure Internet con la porta UDP 24568 aperta sull'host."
	network_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	network_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status.add_theme_font_size_override("font_size", 14)
	network_status.add_theme_color_override("font_color", Color("bdc2dd"))
	online_content.add_child(network_status)
	var close_online := Button.new()
	close_online.text = "INDIETRO"
	close_online.custom_minimum_size = Vector2(170, 40)
	close_online.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close_online.pressed.connect(_hide_online_panel)
	online_content.add_child(close_online)
	online_panel.visible = false
	update_panel = PanelContainer.new()
	update_panel.anchor_left = 0.25
	update_panel.anchor_right = 0.75
	update_panel.anchor_top = 0.25
	update_panel.anchor_bottom = 0.75
	update_panel.z_index = 3
	menu_layer.add_child(update_panel)
	var update_content := VBoxContainer.new()
	update_content.alignment = BoxContainer.ALIGNMENT_CENTER
	update_content.add_theme_constant_override("separation", 12)
	update_panel.add_child(update_content)
	var update_title := Label.new()
	update_title.text = "AGGIORNAMENTI · TAVERN FIGHTER"
	update_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	update_title.add_theme_font_size_override("font_size", 27)
	update_title.add_theme_color_override("font_color", Color("ffc96b"))
	update_content.add_child(update_title)
	var manifest_label := Label.new()
	manifest_label.text = "Indirizzo HTTPS del manifest aggiornamenti"
	manifest_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	update_content.add_child(manifest_label)
	update_manifest_field = LineEdit.new()
	update_manifest_field.placeholder_text = "https://.../latest.json"
	update_manifest_field.custom_minimum_size = Vector2(560, 42)
	update_manifest_field.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	update_content.add_child(update_manifest_field)
	update_status_label = Label.new()
	update_status_label.text = "Versione installata: 1.0.0 · Inserisci il link pubblicato per controllare."
	update_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	update_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	update_status_label.custom_minimum_size = Vector2(550, 48)
	update_content.add_child(update_status_label)
	var check_updates_button := Button.new()
	check_updates_button.text = "SALVA E CONTROLLA"
	check_updates_button.custom_minimum_size = Vector2(300, 42)
	check_updates_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	check_updates_button.pressed.connect(_check_updates)
	update_content.add_child(check_updates_button)
	update_download_button = Button.new()
	update_download_button.text = "SCARICA E INSTALLA"
	update_download_button.custom_minimum_size = Vector2(300, 42)
	update_download_button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	update_download_button.disabled = true
	update_download_button.pressed.connect(_download_update)
	update_content.add_child(update_download_button)
	var close_updates := Button.new()
	close_updates.text = "INDIETRO"
	close_updates.custom_minimum_size = Vector2(180, 38)
	close_updates.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close_updates.pressed.connect(_hide_update_panel)
	update_content.add_child(close_updates)
	update_panel.visible = false

func _spawn_fighters() -> void:
	for fighter in fighters:
		if is_instance_valid(fighter):
			fighter.queue_free()
	fighters.clear()
	var first := FIGHTER_SCENE.instantiate() as StormFighter
	first.configure(0, "RAIJIN", Color("4de2da"), Color("c1fff8"))
	first.position = Vector3(-2.3, 0, 0.7)
	add_child(first)
	var second := FIGHTER_SCENE.instantiate() as StormFighter
	second.configure(1, "VEX", Color("ed638e"), Color("ffd0d9"), not online_mode and not versus_mode)
	second.position = Vector3(2.3, 0, -0.7)
	add_child(second)
	first.set_opponent(second)
	second.set_opponent(first)
	first.remote_controlled = online_mode and not multiplayer.is_server()
	second.remote_controlled = online_mode and multiplayer.is_server()
	fighters = [first, second]
	for index in range(2):
		fighters[index].health_changed.connect(_on_health_changed)
		fighters[index].defeated.connect(_on_defeated)

func _start_game() -> void:
	wins = [0, 0]
	round_number = 1
	for side in round_pips:
		for pip in side:
			pip.color = Color("60617c")
	_start_round()
	menu_layer.visible = false

func _start_round() -> void:
	_spawn_fighters()
	round_time = 99.0
	timer_label.text = "99"
	var round_label := hud_layer.find_child("RoundLabel", true, false) as Label
	round_label.text = "ROUND %02d" % round_number
	fight_state = "intro"
	state_timer = 1.35
	_play_ui_sound(SFX_ROUND, -5.0)
	_show_announcement("ROUND %d" % round_number, "PREPARATI A COMBATTERE", 1.35)
	for bar in health_bars:
		bar.value = 100.0

func _finish_round(winner: int) -> void:
	if fight_state != "fight":
		return
	previous_winner = winner
	_play_ui_sound(SFX_FIGHT, -4.0)
	wins[winner] += 1
	var pip_index: int = wins[winner] - 1
	round_pips[winner][pip_index].color = Color("ffc96b")
	fight_state = "roundover"
	state_timer = 2.0
	_show_announcement("RAIJIN VINCE" if winner == 0 else "VEX VINCE", "COMBATTIMENTO DECISIVO" if wins[winner] == 2 else "ROUND CONQUISTATO", 2.0)

func _on_health_changed(fighter: StormFighter) -> void:
	var index := fighters.find(fighter)
	if index >= 0:
		health_bars[index].value = fighter.health

func _on_defeated(fighter: StormFighter) -> void:
	var index := fighters.find(fighter)
	if index >= 0:
		_finish_round(1 - index)

func _show_announcement(title: String, subtitle: String, duration: float) -> void:
	announcement.text = title
	announcement_subtitle.text = subtitle
	announcement.visible = true
	announcement_subtitle.visible = not subtitle.is_empty()
	state_timer = maxf(state_timer, duration) if fight_state == "over" else state_timer
	var tween := create_tween()
	announcement.modulate.a = 0.0
	tween.tween_property(announcement, "modulate:a", 1.0, 0.18)
	if duration < 10.0:
		tween.tween_interval(maxf(0.1, duration - 0.25))
		tween.tween_property(announcement, "modulate:a", 0.0, 0.25)
		tween.parallel().tween_property(announcement_subtitle, "modulate:a", 0.0, 0.25)

func _toggle_pause() -> void:
	if fight_state == "fight":
		fight_state = "paused"
		_show_announcement("PAUSA", "PREMI ESC PER RIPRENDERE", 999.0)
	elif fight_state == "paused":
		fight_state = "fight"
		announcement.visible = false
		announcement_subtitle.visible = false

func _toggle_mode() -> void:
	versus_mode = not versus_mode
	versus_button.text = "MODALITÀ: 2 GIOCATORI  ·  PREMI PER CAMBIARE" if versus_mode else "MODALITÀ: 1 GIOCATORE  ·  PREMI PER CAMBIARE"

func _show_online_panel() -> void:
	menu_column.visible = false
	online_panel.visible = true
	network_status.text = "Stessa rete: usa l'IP locale. Internet: l'host deve inoltrare la porta UDP 24568."

func _hide_online_panel() -> void:
	online_panel.visible = false
	menu_column.visible = true

func _show_update_panel() -> void:
	menu_column.visible = false
	online_panel.visible = false
	update_panel.visible = true
	var saved_manifest := ConfigFile.new()
	update_manifest_field.text = str(saved_manifest.get_value("updates", "manifest_url", UPDATE_MANIFEST_URL)) if saved_manifest.load("user://update.cfg") == OK else UPDATE_MANIFEST_URL

func _hide_update_panel() -> void:
	update_panel.visible = false
	menu_column.visible = true

func _check_updates() -> void:
	var url := update_manifest_field.text.strip_edges()
	var saved_manifest := ConfigFile.new()
	saved_manifest.set_value("updates", "manifest_url", url)
	var save_result := saved_manifest.save("user://update.cfg")
	if save_result != OK:
		_on_update_failed("Non riesco a salvare il link degli aggiornamenti su questo dispositivo.")
		return
	update_download_button.disabled = true
	updater.check_for_updates(url)

func _download_update() -> void:
	update_download_button.disabled = true
	updater.download_update()

func _on_update_status(message: String) -> void:
	update_status_label.text = message

func _on_update_available(version: String, notes: String) -> void:
	update_status_label.text = "È disponibile la versione %s. %s" % [version, notes]
	update_download_button.disabled = false

func _on_update_failed(message: String) -> void:
	update_status_label.text = message
	update_download_button.disabled = false if not updater.release_url.is_empty() else true

func _on_update_staged(version: String) -> void:
	update_status_label.text = "Installazione della versione %s in corso…" % version

func _host_online_game() -> void:
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_server(NETWORK_PORT, 1)
	if result != OK:
		network_status.text = "Impossibile creare la partita. Codice errore: %s" % error_string(result)
		return
	multiplayer.multiplayer_peer = peer
	if not multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.connect(_on_peer_connected)
	if not multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	online_mode = true
	versus_mode = false
	var local_ip := _find_local_ip()
	network_status.text = "Partita aperta · IP locale %s · porta UDP %d. In attesa dell'altro giocatore…" % [local_ip, NETWORK_PORT]

func _join_online_game() -> void:
	var address := address_field.text.strip_edges()
	if address.is_empty():
		network_status.text = "Inserisci l'indirizzo IP di chi ospita la partita."
		return
	var peer := ENetMultiplayerPeer.new()
	var result := peer.create_client(address, NETWORK_PORT)
	if result != OK:
		network_status.text = "Impossibile collegarsi. Controlla IP e porta UDP %d." % NETWORK_PORT
		return
	multiplayer.multiplayer_peer = peer
	if not multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.connect(_on_connected_to_server)
	if not multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.connect(_on_connection_failed)
	if not multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.connect(_on_server_disconnected)
	online_mode = true
	network_status.text = "Connessione a %s:%d…" % [address, NETWORK_PORT]

func _on_peer_connected(peer_id: int) -> void:
	if not multiplayer.is_server():
		return
	network_client_id = peer_id
	_begin_online_match()

func _on_peer_disconnected(_peer_id: int) -> void:
	if online_mode:
		_return_to_online_menu("L'altro giocatore si è disconnesso.")

func _on_connected_to_server() -> void:
	network_status.text = "Collegato! Avvio della partita…"
	_begin_online_match()

func _on_connection_failed() -> void:
	_return_to_online_menu("Connessione fallita. Verifica IP, porta UDP e firewall dell'host.")

func _on_server_disconnected() -> void:
	_return_to_online_menu("La connessione con chi ospita la partita è stata interrotta.")

func _begin_online_match() -> void:
	online_mode = true
	versus_mode = false
	wins = [0, 0]
	round_number = 1
	for side in round_pips:
		for pip in side:
			pip.color = Color("60617c")
	menu_layer.visible = false
	controls_label.text = "A / D MUOVI     W / S PROFONDITÀ     SPAZIO SALTA     C PARA     J COLPO     K CALCIO     L IMPULSO     ESC PAUSA" if multiplayer.is_server() else "FRECCE MUOVI     ↑ / ↓ PROFONDITÀ     MAIUSC DX SALTA     CTRL DX PARA     1 / 2 / 3 ATTACCHI"
	_start_round()

@rpc("authority", "call_remote", "reliable")
func remote_match_started() -> void:
	_begin_online_match()

@rpc("any_peer", "call_remote", "unreliable_ordered")
func receive_remote_input(input_state: Dictionary) -> void:
	if multiplayer.is_server() and multiplayer.get_remote_sender_id() == network_client_id:
		latest_remote_input = input_state

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_online_state(snapshot: Dictionary) -> void:
	if multiplayer.is_server() or not online_mode:
		return
	_apply_online_state(snapshot)

func _send_online_input() -> void:
	if multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var input_state := {
		"left": Input.is_action_pressed("player_2_left"),
		"right": Input.is_action_pressed("player_2_right"),
		"far": Input.is_action_pressed("player_2_far"),
		"near": Input.is_action_pressed("player_2_near"),
		"guard": Input.is_action_pressed("player_2_guard"),
		"jump": Input.is_action_just_pressed("player_2_jump"),
		"light": Input.is_action_just_pressed("player_2_light"),
		"heavy": Input.is_action_just_pressed("player_2_heavy"),
		"special": Input.is_action_just_pressed("player_2_special")
	}
	rpc_id(1, "receive_remote_input", input_state)

func _broadcast_online_state() -> void:
	if not multiplayer.is_server() or fighters.size() != 2 or multiplayer.get_peers().is_empty():
		return
	var fighter_states: Array[Dictionary] = []
	for fighter in fighters:
		fighter_states.append({
			"position": fighter.global_position,
			"velocity": fighter.velocity,
			"health": fighter.health,
			"guard": fighter.guard_active,
			"attack_timer": fighter.attack_timer,
			"attack_kind": fighter.attack_kind,
			"stun_timer": fighter.stun_timer,
			"facing": fighter.facing,
			"action": fighter.action
		})
	rpc("receive_online_state", {
		"fighters": fighter_states,
		"state": fight_state,
		"round": round_number,
		"time": round_time,
		"wins": wins,
		"winner": previous_winner
	})

func _apply_online_state(snapshot: Dictionary) -> void:
	var new_state: String = snapshot.get("state", fight_state)
	var new_round: int = snapshot.get("round", round_number)
	var new_wins: Array = snapshot.get("wins", wins)
	if new_round != round_number:
		round_number = new_round
		var round_label := hud_layer.find_child("RoundLabel", true, false) as Label
		round_label.text = "ROUND %02d" % round_number
	if new_wins.size() == 2:
		wins = [int(new_wins[0]), int(new_wins[1])]
		for side in range(2):
			for pip_index in range(2):
				round_pips[side][pip_index].color = Color("ffc96b") if pip_index < wins[side] else Color("60617c")
	var states: Array = snapshot.get("fighters", [])
	if states.size() == 2 and fighters.size() == 2:
		for index in range(2):
			var fighter_state: Dictionary = states[index]
			var fighter := fighters[index]
			var incoming_health: float = fighter_state.get("health", fighter.health)
			var incoming_action: String = fighter_state.get("action", fighter.action)
			if incoming_health < fighter.health - 0.01:
				fighter.play_network_hit(bool(fighter_state.get("guard", false)))
			elif incoming_action in ["light", "heavy", "special"] and fighter.attack_timer <= 0.0:
				fighter.play_network_attack(incoming_action)
			fighter.global_position = fighter_state.get("position", fighter.global_position)
			fighter.velocity = fighter_state.get("velocity", fighter.velocity)
			fighter.health = fighter_state.get("health", fighter.health)
			fighter.guard_active = fighter_state.get("guard", fighter.guard_active)
			fighter.attack_timer = fighter_state.get("attack_timer", fighter.attack_timer)
			fighter.attack_kind = fighter_state.get("attack_kind", fighter.attack_kind)
			fighter.stun_timer = fighter_state.get("stun_timer", fighter.stun_timer)
			fighter.facing = fighter_state.get("facing", fighter.facing)
			fighter.action = fighter_state.get("action", fighter.action)
			health_bars[index].value = fighter.health
	round_time = snapshot.get("time", round_time)
	timer_label.text = str(ceili(round_time)).pad_zeros(2)
	previous_winner = int(snapshot.get("winner", previous_winner))
	if new_state != fight_state:
		previous_network_state = fight_state
		fight_state = new_state
		match fight_state:
			"intro": _show_announcement("ROUND %d" % round_number, "PREPARATI A COMBATTERE", 1.0)
			"fight":
				if previous_network_state == "intro":
					_play_ui_sound(SFX_FIGHT, -3.0)
					_show_announcement("FIGHT!", "", 0.6)
			"roundover":
				_play_ui_sound(SFX_FIGHT, -4.0)
				_show_announcement("RAIJIN VINCE" if previous_winner == 0 else "VEX VINCE", "ROUND CONQUISTATO", 1.5)
			"over":
				_play_ui_sound(SFX_FIGHT, -3.0)
				_show_announcement("RAIJIN VINCE" if wins[0] > wins[1] else "VEX VINCE", "PARTITA TERMINATA", 999.0)
			"paused": _show_announcement("PAUSA", "IN ATTESA DELL'HOST", 999.0)

func _return_to_online_menu(message: String) -> void:
	online_mode = false
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	fight_state = "menu"
	menu_layer.visible = true
	menu_column.visible = false
	online_panel.visible = true
	network_status.text = message
	controls_label.text = "A / D MUOVI     W / S PROFONDITÀ     SPAZIO SALTA     C PARA     J COLPO     K CALCIO     L IMPULSO     ESC PAUSA"

func _find_local_ip() -> String:
	for address in IP.get_local_addresses():
		if not address.begins_with("127.") and not address.begins_with("169.254.") and not address.contains(":"):
			return address
	return "non trovato"

func _flat_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 3
	style.corner_radius_top_right = 3
	style.corner_radius_bottom_left = 3
	style.corner_radius_bottom_right = 3
	return style

func _play_ui_sound(stream: AudioStream, volume: float) -> void:
	if ui_sound_player:
		ui_sound_player.stream = stream
		ui_sound_player.volume_db = volume
		ui_sound_player.play()
