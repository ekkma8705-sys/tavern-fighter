extends CharacterBody3D
class_name StormFighter

signal health_changed(fighter: StormFighter)
signal defeated(fighter: StormFighter)

@export var player_index := 0
@export var display_name := "RAIJIN"
@export var tint := Color("4de2da")
@export var accent := Color("c1fff8")
@export var opponent: StormFighter
@export var cpu_controlled := false

const ARENA_X := 6.0
const ARENA_Z := 2.15
const WALK_SPEED := 4.1
const JUMP_SPEED := 7.4
const GRAVITY := 20.0
const SFX_LIGHT := preload("res://audio/light.wav")
const SFX_HEAVY := preload("res://audio/heavy.wav")
const SFX_IMPACT := preload("res://audio/impact.wav")
const SFX_GUARD := preload("res://audio/guard.wav")
const SFX_JUMP := preload("res://audio/jump.wav")
const SFX_SPECIAL := preload("res://audio/special.wav")

var health := 100.0
var vertical_speed := 0.0
var attack_timer := 0.0
var attack_cooldown := 0.0
var hit_applied := false
var attack_kind := ""
var stun_timer := 0.0
var guard_active := false
var flash_timer := 0.0
var facing := 1.0
var cpu_think := 0.0
var cpu_attack_delay := 0.0
var action := "idle"
var animation_time := 0.0
var body_visual: Node3D
var arms: Array[MeshInstance3D] = []
var legs: Array[MeshInstance3D] = []
var shield_visual: MeshInstance3D
var remote_controlled := false
var sound_player: AudioStreamPlayer

func _ready() -> void:
	sound_player = AudioStreamPlayer.new()
	sound_player.name = "SoundEffects"
	add_child(sound_player)
	_build_character()

func _process(delta: float) -> void:
	animation_time += delta
	if attack_cooldown > 0.0:
		attack_cooldown = maxf(0.0, attack_cooldown - delta)
	if attack_timer > 0.0:
		attack_timer = maxf(0.0, attack_timer - delta)
	if stun_timer > 0.0:
		stun_timer = maxf(0.0, stun_timer - delta)
	if flash_timer > 0.0:
		flash_timer = maxf(0.0, flash_timer - delta)
	if not is_instance_valid(opponent):
		return
	facing = 1.0 if opponent.global_position.x >= global_position.x else -1.0
	if body_visual:
		body_visual.rotation.y = 0.0 if facing > 0.0 else PI
		_animate_character()

func configure(index: int, fighter_name: String, fighter_tint: Color, fighter_accent: Color, is_cpu := false) -> void:
	player_index = index
	display_name = fighter_name
	tint = fighter_tint
	accent = fighter_accent
	cpu_controlled = is_cpu
	if is_inside_tree():
		_rebuild_character()

func set_opponent(other: StormFighter) -> void:
	opponent = other

func tick_fight(delta: float, remote_input: Dictionary = {}) -> void:
	if health <= 0.0:
		return
	var input_vector := Vector2.ZERO
	guard_active = false
	if stun_timer <= 0.0:
		if cpu_controlled:
			input_vector = _cpu_input(delta)
		elif remote_controlled:
			input_vector = Vector2(float(remote_input.get("right", false)) - float(remote_input.get("left", false)), float(remote_input.get("near", false)) - float(remote_input.get("far", false))).limit_length(1.0)
			guard_active = bool(remote_input.get("guard", false))
		else:
			input_vector = _player_input()
			guard_active = Input.is_action_pressed(_action("guard"))
		if input_vector.length_squared() > 0.0:
			global_position.x += input_vector.x * WALK_SPEED * delta
			global_position.z += input_vector.y * WALK_SPEED * 0.58 * delta
		var wants_jump := bool(remote_input.get("jump", false)) if remote_controlled else Input.is_action_just_pressed(_action("jump"))
		if not cpu_controlled and wants_jump and is_on_floor():
			velocity.y = JUMP_SPEED
			jump()
		if not cpu_controlled:
			if remote_controlled:
				if bool(remote_input.get("light", false)):
					_start_attack("light")
				elif bool(remote_input.get("heavy", false)):
					_start_attack("heavy")
				elif bool(remote_input.get("special", false)):
					_start_attack("special")
			else:
				_read_attacks()
	else:
		guard_active = false
	velocity.x = move_toward(velocity.x, 0.0, 24.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 18.0 * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = maxf(0.0, velocity.y)
	move_and_slide()
	global_position.x = clampf(global_position.x, -ARENA_X, ARENA_X)
	global_position.z = clampf(global_position.z, -ARENA_Z, ARENA_Z)
	_update_action(input_vector)
	if attack_timer > 0.0 and not hit_applied and attack_timer < _active_window():
		_try_attack_hit()
	_update_shield()

func receive_hit(damage: float, knockback: float, attacker_direction: float, kind: String) -> void:
	var final_damage := damage
	if guard_active and is_on_floor():
		final_damage *= 0.18
		_spawn_spark(Color("8aeaff"))
		_play_sound(SFX_GUARD, -5.0)
	else:
		stun_timer = 0.38 if kind == "light" else 0.58
		velocity.x = attacker_direction * knockback
		if kind == "heavy":
			velocity.y = 2.6
		flash_timer = 0.16
		_spawn_spark(accent)
		_play_sound(SFX_IMPACT, -2.0)
	health = maxf(0.0, health - final_damage)
	health_changed.emit(self)
	if health <= 0.0:
		defeated.emit(self)

func _player_input() -> Vector2:
	var left := _action("left")
	var right := _action("right")
	var far := _action("far")
	var near := _action("near")
	return Vector2(Input.get_axis(left, right), Input.get_axis(far, near)).limit_length(1.0)

func _cpu_input(delta: float) -> Vector2:
	if not is_instance_valid(opponent):
		return Vector2.ZERO
	cpu_think -= delta
	var difference := opponent.global_position - global_position
	var distance_x := absf(difference.x)
	if cpu_think <= 0.0:
		cpu_think = randf_range(0.11, 0.24)
		if distance_x > 1.22:
			cpu_attack_delay = 0.0
		elif cpu_attack_delay <= 0.0 and absf(difference.z) < 0.8:
			cpu_attack_delay = randf_range(0.22, 0.8)
			if randf() < 0.22:
				_start_attack("special")
			elif randf() < 0.60:
				_start_attack("light" if randf() < 0.64 else "heavy")
		cpu_attack_delay = maxf(0.0, cpu_attack_delay - 0.17)
	if distance_x > 1.18:
		return Vector2(signf(difference.x), signf(difference.z) if absf(difference.z) > 0.35 else 0.0)
	if distance_x < 0.80:
		return Vector2(-signf(difference.x) * 0.3, signf(difference.z))
	return Vector2(0.0, signf(difference.z) if absf(difference.z) > 0.65 else 0.0)

func _read_attacks() -> void:
	if Input.is_action_just_pressed(_action("light")):
		_start_attack("light")
	elif Input.is_action_just_pressed(_action("heavy")):
		_start_attack("heavy")
	elif Input.is_action_just_pressed(_action("special")):
		_start_attack("special")

func _start_attack(kind: String) -> void:
	if attack_cooldown > 0.0 or attack_timer > 0.0 or stun_timer > 0.0:
		return
	attack_kind = kind
	attack_timer = 0.30 if kind == "light" else (0.44 if kind == "heavy" else 0.58)
	attack_cooldown = 0.34 if kind == "light" else (0.64 if kind == "heavy" else 1.12)
	hit_applied = false
	if kind == "light":
		_play_sound(SFX_LIGHT, -3.0)
	elif kind == "heavy":
		_play_sound(SFX_HEAVY, -2.0)
	if kind == "special":
		_play_sound(SFX_SPECIAL, -3.0)
		_spawn_projectile()

func play_network_hit(blocked: bool) -> void:
	_play_sound(SFX_GUARD if blocked else SFX_IMPACT, -3.0)

func play_network_attack(kind: String) -> void:
	if kind == "light":
		_play_sound(SFX_LIGHT, -3.0)
	elif kind == "heavy":
		_play_sound(SFX_HEAVY, -2.0)
	elif kind == "special":
		_play_sound(SFX_SPECIAL, -3.0)

func _play_sound(stream: AudioStream, volume: float) -> void:
	if sound_player:
		sound_player.stream = stream
		sound_player.volume_db = volume
		sound_player.play()

func _try_attack_hit() -> void:
	if attack_kind == "special" or not is_instance_valid(opponent):
		return
	var difference := opponent.global_position - global_position
	var reach := 1.75 if attack_kind == "heavy" else 1.34
	if absf(difference.x) > reach or absf(difference.z) > 0.88:
		return
	if difference.x * facing < -0.2:
		return
	hit_applied = true
	opponent.receive_hit(13.0 if attack_kind == "heavy" else 7.0, 5.2 if attack_kind == "heavy" else 2.6, facing, attack_kind)
	_spawn_spark(Color("ffdfac") if attack_kind == "heavy" else accent)

func _spawn_projectile() -> void:
	var projectile := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.22
	mesh.height = 0.44
	projectile.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = tint
	material.emission_enabled = true
	material.emission = tint
	material.emission_energy_multiplier = 4.2
	projectile.material_override = material
	projectile.position = Vector3(facing * 0.85, 1.45, 0)
	add_child(projectile)
	var target := opponent
	var direction := facing
	var origin_x := global_position.x
	var origin_z := global_position.z
	var tween := create_tween()
	tween.tween_property(projectile, "position:x", direction * 7.5, 0.48)
	tween.tween_callback(func() -> void:
		var target_distance := (target.global_position.x - origin_x) * direction if is_instance_valid(target) else 0.0
		if is_instance_valid(target) and target_distance > 0.0 and target_distance < 7.5 and absf(target.global_position.z - origin_z) < 0.95:
			target.receive_hit(11.0, 3.4, direction, "heavy")
		if is_instance_valid(projectile):
			projectile.queue_free())

func _active_window() -> float:
	return 0.18 if attack_kind == "light" else (0.24 if attack_kind == "heavy" else 0.34)

func _action(name: String) -> String:
	if player_index == 0:
		var player_one := {"left": "move_left", "right": "move_right", "far": "move_far", "near": "move_near", "jump": "jump", "light": "light_attack", "heavy": "heavy_attack", "special": "special_attack", "guard": "guard"}
		return player_one[name]
	return "player_2_" + name

func _update_action(input_vector: Vector2) -> void:
	if not is_on_floor():
		action = "air"
	elif stun_timer > 0.0:
		action = "hurt"
	elif guard_active:
		action = "guard"
	elif attack_timer > 0.0:
		action = attack_kind
	elif input_vector.length_squared() > 0.04:
		action = "walk"
	else:
		action = "idle"

func _rebuild_character() -> void:
	for child in get_children():
		child.queue_free()
	_build_character()

func _build_character() -> void:
	body_visual = Node3D.new()
	body_visual.name = "CharacterArt"
	add_child(body_visual)
	var dark := tint.darkened(0.76)
	var torso := _mesh(CapsuleMesh.new(), tint, Vector3(0, 1.23, 0), Vector3(0.53, 0.92, 0.34), "Torso")
	body_visual.add_child(torso)
	var chest := _mesh(BoxMesh.new(), accent, Vector3(0.0, 1.40, -0.19), Vector3(0.31, 0.13, 0.04), "ChestSigil")
	body_visual.add_child(chest)
	var belt := _mesh(BoxMesh.new(), dark, Vector3(0, 0.91, 0), Vector3(0.50, 0.12, 0.37), "Belt")
	body_visual.add_child(belt)
	var head := _mesh(SphereMesh.new(), Color("bd938a") if player_index == 0 else Color("ad798e"), Vector3(0, 1.97, 0), Vector3(0.41, 0.48, 0.38), "Head")
	body_visual.add_child(head)
	var hood := _mesh(SphereMesh.new(), dark, Vector3(0, 2.08, 0.025), Vector3(0.46, 0.34, 0.42), "Hood")
	body_visual.add_child(hood)
	var mask := _mesh(BoxMesh.new(), dark, Vector3(0.035, 1.89, -0.31), Vector3(0.30, 0.15, 0.06), "Mask")
	body_visual.add_child(mask)
	var eye := _mesh(BoxMesh.new(), accent, Vector3(0.10, 2.02, -0.345), Vector3(0.12, 0.025, 0.02), "EyeGlow")
	body_visual.add_child(eye)
	for side in [-1.0, 1.0]:
		var leg := _mesh(CapsuleMesh.new(), dark, Vector3(side * 0.16, 0.43, 0), Vector3(0.26, 0.65, 0.27), "Leg")
		body_visual.add_child(leg)
		legs.append(leg)
		var boot := _mesh(BoxMesh.new(), Color("101323"), Vector3(side * 0.17, 0.12, -0.05), Vector3(0.32, 0.18, 0.42), "Boot")
		body_visual.add_child(boot)
		var arm := _mesh(CapsuleMesh.new(), tint, Vector3(side * 0.42, 1.32, 0), Vector3(0.25, 0.54, 0.26), "Arm")
		body_visual.add_child(arm)
		arms.append(arm)
	var scarf := _mesh(BoxMesh.new(), accent, Vector3(-0.36, 1.68, 0.16), Vector3(0.78, 0.10, 0.10), "Scarf")
	body_visual.add_child(scarf)
	var shield_material := StandardMaterial3D.new()
	shield_material.albedo_color = Color(0.35, 0.84, 1.0, 0.20)
	shield_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shield_material.emission_enabled = true
	shield_material.emission = Color("4bdcff")
	shield_visual = _mesh(SphereMesh.new(), Color(0.35, 0.84, 1.0, 0.20), Vector3(0, 1.1, 0), Vector3(1.05, 1.35, 0.56), "GuardShield")
	shield_visual.material_override = shield_material
	shield_visual.visible = false
	body_visual.add_child(shield_visual)

func _mesh(mesh: PrimitiveMesh, color: Color, at: Vector3, scale: Vector3, node_name: String) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	item.name = node_name
	item.mesh = mesh
	item.position = at
	item.scale = scale
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.38
	material.metallic = 0.1
	if color == accent or color == tint:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 0.35
	item.material_override = material
	return item

func _animate_character() -> void:
	var step := sin(animation_time * 10.0) * (0.11 if action == "walk" else 0.025)
	if legs.size() == 2:
		legs[0].rotation.x = step
		legs[1].rotation.x = -step
	if arms.size() == 2:
		arms[0].rotation.x = -step * 0.75
		arms[1].rotation.x = step * 0.75
	if action == "light" or action == "heavy" or action == "special":
		arms[1].rotation.z = -0.85 if facing > 0.0 else 0.85
	else:
		arms[1].rotation.z = 0.0
	body_visual.position.y = 0.025 * sin(animation_time * 4.0) if action == "idle" else 0.0
	shield_visual.visible = guard_active
	body_visual.scale = Vector3.ONE * (1.08 if flash_timer > 0.0 else 1.0)

func _update_shield() -> void:
	if is_instance_valid(shield_visual):
		shield_visual.visible = guard_active

func _spawn_spark(color: Color) -> void:
	var light := OmniLight3D.new()
	light.light_color = color
	light.light_energy = 2.8
	light.omni_range = 2.1
	light.position = Vector3(facing * 0.8, 1.25, -0.4)
	add_child(light)
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, 0.18)
	tween.tween_callback(light.queue_free)

func jump() -> void:
	velocity.y = JUMP_SPEED
	_play_sound(SFX_JUMP, -4.0)
